
package com.codeoftheweb.salvo.models;

import javax.persistence.*;
import java.util.*;
import java.util.stream.Collectors;

import org.hibernate.annotations.GenericGenerator;

@Entity
public  class   GamePlayer{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native",  strategy = "native")
    private long id;

    private Date  joinDate;

    @ManyToOne(fetch  = FetchType.EAGER)
    @JoinColumn(name="game_id")
    private Game  game;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="player_id")
    private Player player;

    public  GamePlayer(){}

    public  GamePlayer(Game game, Player player){     
      this.game = game;
      this.player = player;
    }

    public  void  setGame(Game  game){
      this.game = game;
    }

    public  void  setPlayer(Player  player){
      this.player = player;
    }

    public  void  setJoinDate(Date  joinDate){
      this.joinDate = joinDate;
    }

    public  Game  getGame(){
      return  this.game;
    }

    public  Player  getPlayer(){
      return  this.player;
    }

    public  Map<String,Object>  dto(){
        Map<String,Object> dto =   new LinkedHashMap<>();
        dto.put("id",   this.id);
        dto.put("joinDate",   this.joinDate);
        dto.put("player",  this.getPlayer().dto());
        return  dto;
    }

}