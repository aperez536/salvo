package com.codeoftheweb.salvo.models;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import java.util.Date;
import java.util.*;
import java.util.stream.Collectors;

@Entity
public class Game {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native",  strategy = "native")
    private long id;

    private Date creationDate;

    @OneToMany(mappedBy="game", fetch=FetchType.EAGER)
    private List<GamePlayer>    gamePlayers;

    public Game(){
        this.creationDate   =   new Date();
    }

    public long getId() {
        return id;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public List<GamePlayer> getGamePlayers() {
        return gamePlayers;
    }

    public void setGamePlayers(List<GamePlayer> gamePlayers) {
        this.gamePlayers = gamePlayers;
    }

    public  Map<String,Object>  dto(){
        Map<String,Object> dto =   new LinkedHashMap<>();
        dto.put("id",   this.id);
        dto.put("created",   this.creationDate);
        dto.put("gamePlayers",  this.gamePlayers.stream().map(gamePlayer -> gamePlayer.dto()).collect(Collectors.toList()));
        return  dto;
    }
}
