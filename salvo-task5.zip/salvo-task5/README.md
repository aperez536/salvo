Proyecto Salvo

En esta tarea tenemos dos opciones, al ejecutar el proyecto ya estaran andando las dos opciones pero en diferentes html. 

Opcion uno games.html // es la que te pide la plataforma es la opcion mas complicada.

Opcion dos games_2.html // es una variante y se crea una nueva api /leaderBoard 